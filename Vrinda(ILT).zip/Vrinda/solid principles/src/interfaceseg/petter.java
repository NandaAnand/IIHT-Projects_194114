package interfaceseg;

public interface petter {
	void pet();


}
