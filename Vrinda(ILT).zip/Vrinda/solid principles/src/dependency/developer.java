package dependency;

public interface developer {
	 void develop();
}
