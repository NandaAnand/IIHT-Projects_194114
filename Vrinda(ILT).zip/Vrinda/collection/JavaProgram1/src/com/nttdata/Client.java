package com.nttdata;

import java.util.Scanner;

public class Client {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n;
	     do
		{
	    	 System.out.println("welcome to vehicle simulation");
	    	 
	    	 System.out.println("press below numbers for more details");
	    	 System.out.println("1. Car \t 2. Bike \t 3. Bus \t 4. Quit");
	    	 n=s.nextInt();
	    	 switch(n)
	    	 {
	    	 case 1:
	    		 {
	    			 Car c=new Car();
	    		 
	    	 			c.input();
	    	 			c.display();
	    	 			int ch;
	    	 			do{
	    	 				System.out.println("1.start\t2.stop\t3.quit");
	    	 				System.out.println("enter the choice");
	    	 				ch=s.nextInt();
	    	 				switch(ch)
	    	 				{
	    	 					case 1:
	    	 						{
	    	 							c.start();
	    	 						}
	    	 						
	    	 							break;
	    	 						
	    	 					case 2:
	    	 						{
	    	 							c.stop();
	    	 						}
	    	 							break;
	    	 					
	    	 				}
	    	 				
	    	 			}while(ch!=3);
	    		 }
	    	 		break;
	    		 
	    	 
	    	 			
	    	 case 2:	Bike b=new Bike();
	 					b.input();
	 					b.display();
	 					int ch1;
	 					do{
	 						System.out.println("1.start\t2.stop\t3.quit");
	 						System.out.println("enter the choice");
	 						ch1=s.nextInt();
	 						switch(ch1)
	 						{
	 							case 1:b.start();
	 									break;
	 							case 2:b.stop();
	 									break;
	 							
	 						}
	 					}while(ch1!=3);
	 					break;
			case 3:		Bus bus=new Bus();
						bus.input();
							bus.display();
							int ch2;
							do{
									System.out.println("1.start\t2.stop\t3.quit");
											System.out.println("enter the choice");
											ch2=s.nextInt();
											switch(ch2)
											{
						case 1:bus.start();
								break;
						case 2:bus.stop();
								break;
					
					}
				}while(ch2!=3);
							break;
			case 4:System.exit(0);
	    	 }
	    	
	    	 
		}while(n!=5);
	}
}
