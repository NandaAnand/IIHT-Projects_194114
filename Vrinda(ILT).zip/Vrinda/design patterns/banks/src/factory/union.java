package factory;

public class union implements rbi{

	@Override
	public void interest() {
		// TODO Auto-generated method stub
		double p=300;
		double t=5;
		double rate=0.12;
		

	    System.out.println("The  interest  is"+(rate*p*t)/100);
		
	}


}
