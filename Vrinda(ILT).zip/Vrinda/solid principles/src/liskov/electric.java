package liskov;

public class electric implements car {

	@Override
	public void turnOnEngine() {
		// TODO Auto-generated method stub
		throw new AssertionError("I don't have an engine!");
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("crazy");
	}

}
