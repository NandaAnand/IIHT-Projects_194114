package com.nttdata.autowire;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Categories {
private String C_name;
public List<Book> getBook() {
	return book;
}
public void setBook(List<Book> book) {
	this.book = book;
}
private List<Book> book;
public String getC_name() {
	return C_name;
}
public void setC_name(String c_name) {
	C_name = c_name;
}

public void details(){
    System.out.println("category name : " + C_name);
    System.out.println("the details of book are"+getBook());
  
    
}
@Override
public String toString() {
	return "Categories [C_name=" + C_name + ", book=" + book + "]";
}

public Categories()
{
	
}
}