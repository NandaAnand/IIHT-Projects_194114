package openclosed;

public class area {
	public static void main(String args[])
	{

	rectangle s=new rectangle();
	s.calculateArea();
	circle c=new circle();
	c.calculateArea();
	}
}

