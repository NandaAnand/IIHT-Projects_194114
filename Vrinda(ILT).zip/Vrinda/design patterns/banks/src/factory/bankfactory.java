package factory;

class bankFactory
{
  public static rbi getinterest(String criteria)
  {
    if ( criteria.equals("sbi") )
      return new sbi();
   
    else if ( criteria.equals("union") )
      return new union();

    return null;
  }
}