package com.nttdata;

import java.util.Comparator;
import java.util.Scanner;

public class Employee implements Comparable<Employee> {
private int emp_id;
private String emp_name;
private String emp_add;
private double emp_sal;
private String emp_grade;


public int getEmp_id() {
	return emp_id;
}
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}
public String getEmp_name() {
	return emp_name;
}
public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}
public String getEmp_add() {
	return emp_add;
}
public void setEmp_add(String emp_add) {
	this.emp_add = emp_add;
}
public double getEmp_sal() {
	return emp_sal;
}
public void setEmp_sal(double emp_sal) {
	this.emp_sal = emp_sal;
}
public String getEmp_grade() {
	return emp_grade;
}
public void setEmp_grade(String emp_grade) {
	this.emp_grade = emp_grade;
}
public Employee(int emp_id, String emp_name, String emp_add, double emp_sal, String emp_grade) {
	super();
	this.emp_id = emp_id;
	this.emp_name = emp_name;
	this.emp_add = emp_add;
	this.emp_sal = emp_sal;
	this.emp_grade = emp_grade;
}
@Override
public String toString() {
	return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_add=" + emp_add + ", emp_sal=" + emp_sal
			+ ", emp_grade=" + emp_grade + "]";
}
void input()
{
	
}


@Override
public int compareTo(Employee e) {
	// TODO Auto-generated method stub
	if(emp_id>e.emp_id)
	{
		return 1;
	}else if(emp_id<e.emp_id)
	{
		return -1;
	}else
	{
	return 0;
}
}
}
