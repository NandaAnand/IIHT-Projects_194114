package factory;

public interface rbi {
	abstract void interest ();

	
}
