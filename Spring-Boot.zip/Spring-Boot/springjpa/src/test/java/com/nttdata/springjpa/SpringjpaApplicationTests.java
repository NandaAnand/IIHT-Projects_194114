package com.nttdata.springjpa;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
@SpringBootTest
public class SpringjpaApplicationTests {

	@Test
public	void contextLoads() {
	}

}
