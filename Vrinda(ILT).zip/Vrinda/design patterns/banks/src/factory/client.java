package factory;

import java.util.Scanner;

public class client {
	
	public static void main(String[] args) {
		
		rbi r = bankFactory.getinterest("sbi");
	    r.interest();

	    rbi r1 = bankFactory.getinterest("union");
	    r1.interest();


	}

}
