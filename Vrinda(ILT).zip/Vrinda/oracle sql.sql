 alter user HR identified by hr account unlock;
  grant connect,resource to hr;
  select * from hr.employees;
   select * from hr.departments;
    select * from hr.jobs;
    select * from hr.job_history;
    
    
select * from hr.jobs where min_salary > 10000;


    
select first_name, hire_date from hr.employees where TO_CHAR(hire_date, 'YYYY') between 2002 and 2005 order by hire_date;

    
    
select first_name, hire_date from hr.employees where job_id ='IT_PROG' or job_id='SA_MAN';


  
select *  from  hr.employees where hire_date>'01-jan-2008';


  
select TO_CHAR(hire_date,'MM') month, count(*)counts  from hr.employees where TO_CHAR(hire_date,'YYYY')= TO_CHAR(sysdate,'YYYY') group by TO_CHAR(hire_date,'MM');


  
 select job_id ,avg(salary) average_salary from hr.employees group by job_id having avg(salary)>10000;
 
 
 
 update hr.employees set salary = 8000 where employee_id = 115 and salary < 6000;
 
 
 
select d.department_id,d.department_name from hr.departments d 
WHERE d.department_id IN(select distinct department_id from hr.employees group by department_id, manager_id
having count(employee_id) > 5);



select * from hr.departments where manager_id in (select employee_id from hr.employees where first_name='Smith');



select first_name, job_title, start_date, end_date from hr.job_history j1 
join hr.jobs j2 on (j2.job_id=j1.job_id)
join hr.employees e on (j1.employee_id=e.employee_id) where commission_pct is null;



 
