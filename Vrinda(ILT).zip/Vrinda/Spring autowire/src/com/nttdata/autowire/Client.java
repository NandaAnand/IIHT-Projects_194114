package com.nttdata.autowire;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Resource res=new ClassPathResource("SpringSet.xml");
	BeanFactory factory=new XmlBeanFactory(res);
	List<Book> books=new ArrayList<>();
	Object o=factory.getBean("categories");
		Categories cat=(Categories)o;
	System.out.println("enter the category name");
	String name=sc.next();
	
	System.out.println("enter the number of books under this category");
	int n=sc.nextInt();
	
	for(int i=0;i<n;i++)
	{
	Object o1=factory.getBean("book");
	Book b=(Book)o1;
	System.out.println("enter the bookid");
b.setBid(sc.nextInt());
System.out.println("enter the bookname");
b.setBookname(sc.next());
System.out.println("enter the price");
b.setPrice(sc.nextFloat());
	
books.add(b);

	}
	cat.setC_name(name);
	cat.setBook(books);
	cat.details();
}


}

