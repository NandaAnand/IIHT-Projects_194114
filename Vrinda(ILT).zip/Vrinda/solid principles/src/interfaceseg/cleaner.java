package interfaceseg;

public interface cleaner {
	void wash();

}
