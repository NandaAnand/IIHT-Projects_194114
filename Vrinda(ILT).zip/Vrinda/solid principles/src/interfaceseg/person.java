package interfaceseg;

public class person implements petter {

	@Override
	public void pet() {
		// TODO Auto-generated method stub
		System.out.println("pet the animal");
	}

}
