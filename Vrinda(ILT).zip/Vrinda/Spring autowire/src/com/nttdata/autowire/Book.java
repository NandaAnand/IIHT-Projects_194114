package com.nttdata.autowire;

public class Book {
private int bid;
private String bookname;
private float price;
public int getBid() {
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
@Override
public String toString() {
	return "Book [bid=" + bid + ", bookname=" + bookname + ", price=" + price + "]";
}

}
