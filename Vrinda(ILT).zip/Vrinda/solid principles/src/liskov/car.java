package liskov;

public interface car {
	 void turnOnEngine();
	    void accelerate();
}
