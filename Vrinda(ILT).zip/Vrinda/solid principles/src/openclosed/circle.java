package openclosed;

public class circle  implements shape {
	public double radius=10;
	
	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		System.out.println("area of circle"+ (22/7)*radius*radius);
	}
}
