package factory;

public class sbi implements rbi{

	public void interest() {
		// TODO Auto-generated method stub
		double rate=0.06;

	    double p=200;
	   double t=3;
		System.out.println("The interest  is"+(rate*p*t)/100);
		
	}

	


}
