package dependency;

public class frontend implements developer{

	@Override
	public void develop() {
		// TODO Auto-generated method stub
		writeJavascript();
	}
	 public void writeJavascript() {
		 System.out.println("hi this is javascript");
	    }
}
