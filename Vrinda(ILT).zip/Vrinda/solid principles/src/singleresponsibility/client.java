package singleresponsibility;



public class client {
	public static void main(String[] args)
	{
	book b=new book();
	b.author();
	b.title();
	
	
	}
	

}
