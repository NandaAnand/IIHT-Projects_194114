package com.nttdata.springs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsApplicationTests {

	@Test
	void contextLoads() {
	}

}
