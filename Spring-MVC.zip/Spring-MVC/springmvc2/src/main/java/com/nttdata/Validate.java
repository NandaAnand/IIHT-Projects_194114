package com.nttdata;

import org.springframework.stereotype.Service;

@Service
public class Validate {
public boolean validate(String name,String password){
	
if(name.equals("vrinda") && password.equals("vrinda"))
	return true;
return false;
}

}
