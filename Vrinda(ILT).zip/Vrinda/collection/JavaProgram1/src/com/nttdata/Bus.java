package com.nttdata;

import java.util.Scanner;

public class Bus extends Vehicle {
	private int bus_no;
	private String bus_name;
	private double price;
	Scanner s=new Scanner(System.in);
	public int getBus_no() {
		return bus_no;
	}
	public void setBus_no(int bus_no) {
		this.bus_no = bus_no;
	}
	public String getBus_name() {
		return bus_name;
	}
	public void setBus_name(String bus_name) {
		this.bus_name = bus_name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Bus(int bus_no, String bus_name, double price) {
		super();
		this.bus_no = bus_no;
		this.bus_name = bus_name;
		this.price = price;
	}
	public Bus() {
		// TODO Auto-generated constructor stub
	}
	void input()
	{
		System.out.println("welcome to bus....");
		System.out.println("Enter the bus_no");
		setBus_no(s.nextInt());
		System.out.println("enter the bus name");
		setBus_name(s.next());
		System.out.println("enter the price");
		setPrice(s.nextDouble());
	}
	void display()
	{
		System.out.println("car no is"+"\t"+getBus_no()+"\t"+"car name is"+"\t"+getBus_name()+"\t"+"price"+"\t"+getPrice());
	}
	@Override
	void start() {
		// TODO Auto-generated method stub
		System.out.println("Bus has started");
	}
	@Override
	void stop() {
		// TODO Auto-generated method stub
		System.out.println("bike has stopped");
	}
}
