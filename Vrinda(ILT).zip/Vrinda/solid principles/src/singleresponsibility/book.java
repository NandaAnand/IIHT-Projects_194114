package singleresponsibility;

public class book { 
	String author="jane auston";
	String title="pride and prejudice";
	public void author(){
		
		
		System.out.println("author name is"+author);
	}
    
	public void title(){
		System.out.println("title is:"+title);
	}
    
}
