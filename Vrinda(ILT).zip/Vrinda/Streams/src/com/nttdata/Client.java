package com.nttdata;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class Client {
public static void main(String[] args) {
	List<Employee> list=new ArrayList<>();
	List<String> emplist=new ArrayList<>();
	list.add(new Employee(1,"vrinda",50000));
	list.add(new Employee(2,"nanda",10000));
	list.add(new Employee(3,"harshitha",60000));
	list.add(new Employee(4,"vibha",20000));
	list.add(new Employee(5,"shikha",1000));
	
	System.out.println("The employee details are\n"+list);
	
	 emplist=list.stream().filter(e->e.emp_sal>20000).map(e->e.emp_name).collect(Collectors.toList());
	 System.out.println(" employees whose salaries greater than 20000 is\n");
	 System.out.println(emplist);
	 long emp=list.stream().filter(e->e.emp_sal>20000).map(e->e.emp_sal).collect(Collectors.counting());
	 System.out.println("\nnumber of employees having salaries greater than 20000:\t"+emp);
	
	
}
}
