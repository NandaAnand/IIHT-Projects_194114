package com.nttdata;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;


public class Client {
	 static TreeSet<Employee> set=new TreeSet<Employee>();
	 Scanner s=new Scanner(System.in);
	void input(int n)
	{
	
	for(int i=0;i<n;i++)
	{
	System.out.println("enter the id");
	int emp_id=s.nextInt();
	System.out.println("enter the name");
	String emp_name=s.next();
	System.out.println("enter the address");
	String emp_add=s.next();
	System.out.println("enter the salary");
	double emp_sal=s.nextDouble();
	System.out.println("enter the grade");
	String emp_grade=s.next();
	
	Employee emp=new Employee(emp_id,emp_name,emp_add,emp_sal,emp_grade);
	set.add(emp);
	}
	
	}
	public static void main(String[] args) {
		
		Client c=new Client();
		int n;
		Scanner s=new Scanner(System.in);
		do
		{
			
		System.out.println("enter no of employee details to b stored");
	 n=s.nextInt();
		c.input(n);
		
		for(Employee se:set){
			System.out.println(se.toString());
			
	}

	}while(n!=0);
}
}
