package com.nttdata.springjpa.entity;

public enum ReviewRating {
	ZERO, ONE, TWO, THREE, FOUR, FIVE
}
