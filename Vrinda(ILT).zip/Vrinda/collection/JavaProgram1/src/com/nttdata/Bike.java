package com.nttdata;

import java.util.Scanner;

public class Bike extends Vehicle {
private int bike_no;
private String bike_name;
private double price;
Scanner s=new Scanner(System.in);
public int getBike_no() {
	return bike_no;
}
public void setBike_no(int bike_no) {
	this.bike_no = bike_no;
}
public String getBike_name() {
	return bike_name;
}
public void setBike_name(String bike_name) {
	this.bike_name = bike_name;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Bike(int bike_no, String bike_name, double price) {
	super();
	this.bike_no = bike_no;
	this.bike_name = bike_name;
	this.price = price;
}
public Bike() {
	// TODO Auto-generated constructor stub
}

void input()
{
	System.out.println("welcome to bike....");
	System.out.println("Enter the bike_no");
	setBike_no(s.nextInt());
	System.out.println("enter the bike name");
	setBike_name(s.next());
	System.out.println("enter the price");
	setPrice(s.nextDouble());
}
void display()
{
	System.out.println("car no is"+"\t"+getBike_no()+"\t"+"car name is"+"\t"+getBike_name()+"\t"+"price"+"\t"+getPrice());
}
@Override
void start() {
	// TODO Auto-generated method stub
	System.out.println("Bike has started");
}
@Override
void stop() {
	System.out.println("bike has stopped");// TODO Auto-generated method stub
	
}
}
