package com.nttdata;

import java.util.Scanner;





public class client {
	
public static void main(String[] args) throws InsufficientAmount {
	Scanner s=new Scanner(System.in);
	Account acc1=null;
	User user1=null;
	Account acc2=null;
	User user2=null;
	
	int ch;
	do
	{
		System.out.println("Welcome to bank application");
		System.out.println("1.Create account\n 2.Transfer funds \n 3.Quit");
		System.out.println("enter your choice");
		ch=s.nextInt();
		switch(ch)
		{
		case 1:	int ch1;
				do
				{
					System.out.println("1.Create account for user1\n 2. create account for user2\n 3.Quit");
					System.out.println("enter your choice");
					ch1=s.nextInt();
					switch(ch1)
					{
					case 1:
						
						System.out.println("enter the account id");
						int accid=s.nextInt();
						System.out.println("enter the amount");
						double amt=s.nextDouble();
						
						System.out.println("enter the user name");
						String name=s.next();
						System.out.println("enter the address");
						String adress=s.next();
						System.out.println("enter the phonenumber");
						Long phno=s.nextLong();
						 acc1=new Account(accid,amt);
						 user1=new User(name,adress,phno,acc1);
						 
						
					        System.out.println("account created succesfully!..");
					        break;
					case 2:
						
						System.out.println("enter the account id");
						int accid1=s.nextInt();
						System.out.println("enter the amount");
						double amt1=s.nextDouble();
						
						System.out.println("enter the user name");
						String name1=s.next();
						System.out.println("enter the address");
						String adress1=s.next();
						System.out.println("enter the phonenumber");
						Long phno1=s.nextLong();
						acc2=new Account(accid1,amt1);
						 user2=new User(name1,adress1,phno1,acc2);
						
							System.out.println("account created succesfully!..");
						
						
							break;
					
					}
					
						
				}while(ch1!=3);
				break;
		case 2: int ch2;
				do
				{
					System.out.println("1. Transfer amount from user1 to user2");
					System.out.println("2.Transfer amount from user2 to user1");
					System.out.println("3. Quit");
					System.out.println("enter the choice");
					ch2=s.nextInt();
					switch(ch2)
					{
					case 1: Bank bank=new Bank();
					          System.out.println("user1 account details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
					          System.out.println("user2 account details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t"+user2.getAcc().getAmount());
							
							System.out.println("enter the amount to be tranfered");
							double amount=s.nextDouble();
							try
							{
							bank.TransferFund(user1,user2,amount);
							}catch(InsufficientAmount e){
								e.printStackTrace();
							}
							System.out.println("trasfered amount from user 1 to user 2 successfully!!");
							System.out.println("user1 account details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
							System.out.println("user2 account details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t"+user2.getAcc().getAmount());
							break;
					case 2: Bank bank1=new Bank();
					        System.out.println("user1 account details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
				      	    System.out.println("user2 account details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t"+user2.getAcc().getAmount());
					
							System.out.println("enter the amount to be tranfered");
							double amount1=s.nextDouble();
							try
							{
							bank1.TransferFund(user2,user1,amount1);
							}catch(InsufficientAmount e){
								e.printStackTrace();
							}
							System.out.println("trasfered amount from user 2 to user 1 successfully!!");
							System.out.println("user1 account details\n name is\t"+user1.getUsername()+"\t"+"account id\t"+user1.getAcc().getAccid()+"\t"+"amount\t"+user1.getAcc().getAmount());
							System.out.println("user2 account details\n name is\t"+user2.getUsername()+"\t"+"account id\t"+user2.getAcc().getAccid()+"\t"+"amount\t"+user2.getAcc().getAmount());
							break;
					}
					
				}while(ch2!=3);
			break;
		case 3:System.exit(0);
		}
				
		
	}while(ch!=3);
}
}
