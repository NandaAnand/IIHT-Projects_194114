package com.nttdata.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;
import com.nttdata.employeeDao.EmployeeDao;
import com.nttdata.modal.Employee;

public class EmployeeTest {

	EmployeeDao emp=Mockito.mock(EmployeeDao.class);
	
	
	@Test
	public void testgetEmployeeId()
	{
		Employee employee=new Employee(1,"vrinda",50000,"banglore");
		Mockito.when(emp.getEmpID(employee.getEmp_id())).thenReturn(employee);
	}
	
	
	@Test
	public void testCreateEmployee()
	{
		Employee employee=new Employee(2,"nanda",60000,"banglore");
		Mockito.when(emp.createemployee()).thenReturn(employee);
		
		
	}
	
	
	
	@Test
	public void testEmployeeList()
	{
		List<Employee>list=new ArrayList<>();
		list.add(new Employee(3,"vibha",500000,"banglore"));
		list.add(new Employee(4,"monika",20000,"tumkur"));
		list.add(new Employee(5,"radha",600000,"banglore"));
		Mockito.when(emp.listEmployee()).thenReturn(list);
	}
	
	@Test
	public void testdeleteEmployee()
	{
		Employee employee=new Employee(6,"vaishnavi",80000,"banglore");
		Mockito.when(emp.deleteEmployee(employee.getEmp_id())).thenReturn(employee);
	}
	
	
	@Test
	public void testsearchEmployee()
	{
		Employee employee=new Employee(7,"harshi",80000,"banglore");
		Mockito.when(emp.searchEmployee(employee.getEmp_name())).thenReturn(employee);
	}
	

}
