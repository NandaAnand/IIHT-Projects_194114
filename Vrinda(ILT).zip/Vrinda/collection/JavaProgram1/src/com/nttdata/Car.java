package com.nttdata;

import java.util.Scanner;

public class Car extends Vehicle {
	private int car_no;
	private String car_name;
	private double price;
	Scanner s=new Scanner(System.in);
	
	
	public Car(int car_no, String car_name, double price) {
		super();
		this.car_no = car_no;
		this.car_name = car_name;
		this.price = price;
	}

	public Car() {
		// TODO Auto-generated constructor stub
	}

	public int getCar_no() {
		return car_no;
	}

	public void setCar_no(int car_no) {
		this.car_no = car_no;
	}

	public String getCar_name() {
		return car_name;
	}

	public void setCar_name(String car_name) {
		this.car_name = car_name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	

	
	@Override
	void start() {
		// TODO Auto-generated method stub
		System.out.println("Car has started");
	}

	@Override
	void stop() {
		// TODO Auto-generated method stub
		System.out.println("Car has stopped");
	}

	void input()
	{
		System.out.println("welcome to car....");
		System.out.println("Enter the car_no");
		setCar_no(s.nextInt());
		System.out.println("enter the car name");
		setCar_name(s.next());
		System.out.println("enter the price");
		setPrice(s.nextDouble());
	}
	void display()
	{
		System.out.println("car no is"+"\t"+getCar_no()+"\t"+"car name is"+"\t"+getCar_name()+"\t"+"price"+"\t"+getPrice());
	}
}
