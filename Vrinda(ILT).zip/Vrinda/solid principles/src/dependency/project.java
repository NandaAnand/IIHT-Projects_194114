package dependency;



public class project {
	
	public static void main(String args[])
	{
		backend b=new backend();
		b.develop();
		frontend f=new frontend();
		f.develop();
	}
}
