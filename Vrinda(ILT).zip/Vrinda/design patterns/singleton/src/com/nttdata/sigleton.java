 package com.nttdata;
 import java.io.IOException;
import java.io.BufferedReader;  
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;


public class sigleton {

	static int count=1;  
   
    public static void main(String[] args) throws IOException {  
          
        singleton jdbc= singleton.getInstance();  
          
          
        Scanner sc = new Scanner(System.in);
		
		 
		 System.out.println("Enter customer Id");
			int id=sc.nextInt();
		System.out.println("Enter the amount to withdraw");
		double balance=sc.nextDouble();
		
		
		ResultSet rs;
                      
         try {  
                  int i= jdbc.insert(id, balance);  
                  if (i>0) {  
                	  count++;
                      System.out.println(count + " Data has been inserted successfully");  
                     }else{  
                          System.out.println("Data has not been inserted ");      
                       }  
                          
              } catch (Exception e) {  
                          System.out.println(e);  
                        }  
                       
                   }

}
