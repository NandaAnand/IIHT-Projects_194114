package liskov;

public class motor implements car {

	@Override
	public void turnOnEngine() {
		// TODO Auto-generated method stub
		System.out.println("engine is on");
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("engine accelerataed");
	}

}
