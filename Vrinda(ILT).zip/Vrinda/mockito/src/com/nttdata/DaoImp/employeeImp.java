package com.nttdata.DaoImp;

import java.util.List;

import com.nttdata.employeeDao.EmployeeDao;
import com.nttdata.modal.Employee;

public class employeeImp implements EmployeeDao{

	@Override
	public Employee getEmpID(int id) {
		
		return null;
	}

	@Override
	public Employee createemployee() {
		
		return null;
	}

	@Override
	public List<Employee> listEmployee() {
		
		return null;
	}

	@Override
	public Employee searchEmployee(String name) {
		
		return null;
	}

	@Override
	public Employee deleteEmployee(int id) {
		
		return null;
	}

	
	
	
	
	
	
	
}
