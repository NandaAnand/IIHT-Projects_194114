package com.nttdata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class singleton {
	
	 private static singleton jdbc;  
     
     
       private singleton() {  }  
        
    
         public static singleton getInstance() {    
              if (jdbc==null)  
               {  
                    jdbc=new  singleton();  
               }  
               return jdbc;  
             }  
            
    
          private static Connection getConnection()throws ClassNotFoundException, SQLException  
          {  
                
              Connection con=null;  
              Class.forName("com.mysql.jdbc.Driver");  
              con= DriverManager.getConnection("jdbc:mysql://localhost:3306/nttdata", "root", "Admin123");
              if(con!=null){
            	  System.out.println("Connection Successfull");
              }
              return con;  
                
          }  
            
 
          public int insert(int cid, double balance) throws SQLException  
          {  
              Connection c=null;  
                
              PreparedStatement ps=null;  
                
              int recordCounter=0;  
                
              try {  
                    
                      c=this.getConnection();  
                      ps=c.prepareStatement("insert into bank(cid,balance)values(?,?)");  
                      ps.setInt(1, cid);  
                      ps.setDouble(2, balance);  
                      recordCounter=ps.executeUpdate();  
                        
              } catch (Exception e) { e.printStackTrace(); } finally{  
                    if (ps!=null){  
                      ps.close();  
                  }if(c!=null){  
                      c.close();  
                  }   
              }  
             return recordCounter;  
          }  
	
}
