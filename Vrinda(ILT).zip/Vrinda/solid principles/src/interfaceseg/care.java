package interfaceseg;

public class care implements cleaner, feeder {
	 
    

	@Override
	public void feed() {
		System.out.println("feed the animal ");
		
	}

	@Override
	public void wash() {
		// TODO Auto-generated method stub
		 System.out.println("wash the animal ");
	}
}
