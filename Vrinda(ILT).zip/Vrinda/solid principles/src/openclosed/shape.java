package openclosed;

public interface shape {
	public void calculateArea();
	
}
