package openclosed;

public class rectangle implements shape {
	double length=100;
	double width=10;
	
	
	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		System.out.println("rectangle area"+length * width);
	}}
	 

