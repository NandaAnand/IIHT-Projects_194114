package interfaceseg;

public interface feeder {
	void feed();
}
