package com.nttdata;

public class InsufficientAmount extends Exception {
	
	

	public InsufficientAmount(String message)
	{
		System.out.println("cannot transfer as amount in ur account is less than expected");
	}
	

}
