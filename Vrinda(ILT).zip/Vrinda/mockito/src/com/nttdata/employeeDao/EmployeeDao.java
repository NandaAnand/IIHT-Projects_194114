package com.nttdata.employeeDao;

import java.util.List;

import com.nttdata.modal.Employee;

public interface EmployeeDao {
	
	
	Employee getEmpID(int id);
	Employee createemployee();
	List<Employee> listEmployee(); 
	
	Employee deleteEmployee(int id);
	Employee searchEmployee(String name);

	
	
}
