package com.nttdata;



public abstract class Vehicle {
	
	abstract void start();
	abstract void stop();

	void display()
	{
		System.out.println("displaying types of vehicles");
	}
	    	 
			
		
}
