package interfaceseg;

public class client {
public static void main(String args[]){
	care c=new care();
	c.feed();
	c.wash();
	person p=new person();
	p.pet();
}
}
