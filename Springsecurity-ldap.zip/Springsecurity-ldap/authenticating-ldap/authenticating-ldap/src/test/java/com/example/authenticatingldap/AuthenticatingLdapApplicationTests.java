package com.example.authenticatingldap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticatingLdapApplicationTests {

	@Test
	void contextLoads() {
	}

}
