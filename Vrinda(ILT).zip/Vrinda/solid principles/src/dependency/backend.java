package dependency;

public class backend implements developer {

	@Override
	public void develop() {
		// TODO Auto-generated method stub
		writeJava();
	}
	  private void writeJava() {
		  System.out.println("hi this is java");
	    }

}
