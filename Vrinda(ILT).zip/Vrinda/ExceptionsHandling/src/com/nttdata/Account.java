package com.nttdata;

public class Account {
	private int accid;
	private double amount;
	public int getAccid() {
		return accid;
	}
	public void setAccid(int accid) {
		this.accid = accid;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Account() {
		super();
	}
	public Account(int accid, double amount) {
		super();
		this.accid = accid;
		this.amount = amount;
	}
	
}
